package com.mig;

import java.io.Reader;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class TestMigrationTest {
    public static void main(String[] args) throws Exception {
        Reader srcReader = Resources.getResourceAsReader("mybatis-config-test-source.xml");
        SqlSessionFactory srcFactory = new SqlSessionFactoryBuilder().build(srcReader);
        srcReader.close();

        Reader tgtReader = Resources.getResourceAsReader("mybatis-config-test-target.xml");
        SqlSessionFactory tgtFactory = new SqlSessionFactoryBuilder().build(tgtReader);
        tgtReader.close();

        try (SqlSession src = srcFactory.openSession();
             SqlSession tgt = tgtFactory.openSession()) {

            int testVal = src.selectOne("brdNoticeSql.selectConnectionTest");
            System.out.println("소스 DB 연결 확인: " + testVal);

            try {
                tgt.insert("brdNoticeSql.insertDummyData");
                tgt.commit();
            } catch (Exception e) {
                System.out.println("INSERT 테스트: " + e.getMessage());
            }
        }
    }
}
