package com.mig;

import java.io.Reader;
import java.util.List;
import java.util.Map;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class TestMigrationProd {
    public static void main(String[] args) throws Exception {
        Reader srcReader = Resources.getResourceAsReader("mybatis-config-source.xml");
        SqlSessionFactory srcFactory = new SqlSessionFactoryBuilder().build(srcReader);
        srcReader.close();

        Reader tgtReader = Resources.getResourceAsReader("mybatis-config-target.xml");
        SqlSessionFactory tgtFactory = new SqlSessionFactoryBuilder().build(tgtReader);
        tgtReader.close();

        try (SqlSession src = srcFactory.openSession();
             SqlSession tgt = tgtFactory.openSession()) {

            List<Map<String, Object>> list = src.selectList("brdNoticeSql.selectNoticeList");
            System.out.println("조회 건수: " + list.size());

            for (Map<String, Object> row : list) {
                tgt.insert("brdNoticeSql.insertNoticeData", row);
            }
            tgt.commit();
            System.out.println("마이그 완료.");
        }
    }
}
